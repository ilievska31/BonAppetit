package com.bonappetit.bonappetit;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class RecipeDetails extends AppCompatActivity {


    RequestQueue requestQueue;

    String id,calories;
    TextView title;
    final String apiURL = "https://api.spoonacular.com/recipes";
    final String apiID ="apiKey=51c719f6a4674569aef3e2ef6f81fdf0";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_details);

        requestQueue = Volley.newRequestQueue(this);

        title = findViewById(R.id.title);

        Bundle b = getIntent().getExtras();
        id = b.getString("id");
        calories = b.getString("calories");

        sendRequests();


    }

    private void sendRequests() {
        JsonObjectRequest objectRequest = new JsonObjectRequest(
                Request.Method.GET,
                apiURL + "/" + id + "/information?" + apiID,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {

                            ImageView image = findViewById(R.id.image);
                            Picasso.with(getApplicationContext()).load(response.getString("image")).fit().centerCrop().into(image);
                            TextView title = findViewById(R.id.title);
                            title.setText(response.getString("title"));
                            JSONArray temp = response.getJSONArray("extendedIngredients");
                            TextView ingredients = findViewById(R.id.ingredients);
                            ingredients.append("Ingredients \n");

                            for (int i=0;i<temp.length();i++) {
                                JSONObject ingredient = temp.getJSONObject(i);
                                String ing = ingredient.getString("original");
                                ingredients.append(ing+"\n");
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                }
        );
        requestQueue.add(objectRequest);

        JsonArrayRequest arrayRequest = new JsonArrayRequest(
                Request.Method.GET,
                apiURL+"/"+id+"/analyzedInstructions?"+apiID,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        ArrayList<String> inst = new ArrayList<>();

                        try {

                            TextView instructions = findViewById(R.id.instructions);
                            instructions.append("Instructions \n");
                            JSONArray temp = response.getJSONObject(0).getJSONArray("steps");

                            for (int i=0;i<temp.length();i++) {
                                inst.add(temp.getJSONObject(i).getString("number")+". "+temp.getJSONObject(i).getString("step"));
                                instructions.append(temp.getJSONObject(i).getString("number")+". "+temp.getJSONObject(i).getString("step")+"\n");
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                });
        requestQueue.add(arrayRequest);


    }
}
