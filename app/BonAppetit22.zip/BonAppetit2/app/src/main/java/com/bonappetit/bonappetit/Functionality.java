package com.bonappetit.bonappetit;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;

public class Functionality extends AppCompatActivity {

    FragmentTransaction fragmentTransaction;
    Fragment searchRecipe, searchIngredients;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_functionality);


        searchRecipe = new com.bonappetit.bonappetit.searchRecipe();
        searchIngredients = new com.bonappetit.bonappetit.searchIngredients();


        fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.add(R.id.fl_fragment, searchRecipe);
        fragmentTransaction.commit();


        RadioButton sr = findViewById(R.id.search_recipes);
        RadioButton si = findViewById(R.id.search_ingredients);

        sr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragmentTransaction = getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.fl_fragment, searchRecipe);
                fragmentTransaction.commit();

            }
        });

        si.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragmentTransaction = getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.fl_fragment, searchIngredients);
                fragmentTransaction.commit();
            }
        });


    }
}
